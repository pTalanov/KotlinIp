package js

native
class Date() {
    fun getTime() : Int = js.noImpl
}